for (let i = 1; i <= 10; i = i + 1){
    console.log(i);
}

console.log("-------");

let j = 5;
while(j <= 10){
    console.log(j);
    j ++;
}

console.log("-----");
let nombres = ["Ale", "Epi", "Yun", "Emi"];

for(let i = 0; i < nombres.length; i ++){
    console.log(nombres[i]);
}