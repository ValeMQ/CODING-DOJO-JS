
function sumaDosNumeros(){
    let total = num1 + num2;
    return total;

}

let resultado = sumaDosNumeros (20, 30);
console.log(resultado);

let resultado2 = sumaDosNumeros(50, 80);
console.log(resultado2);

let resultadoTotal = sumaDosNumeros(resultado, resultado2);
console.log(resultadoTotal);