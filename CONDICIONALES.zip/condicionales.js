let calificacion = 10.0;
let calificacion = 8.7;
let calificacion = 6.7;

if(calificacion >= 8.0){
    console.log ("has aprobado tu examen");
    if(calificacion === 10.0){
        console.log("Obtuviste la calificacion mas alta")
    }
}
else{
    console.log ("no aprobaste tu examen");
}
console.log("Expresion finalizada.");