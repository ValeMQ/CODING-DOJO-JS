let numeros = [10, 20, 30, 40, 50];

console.log(numeros);
console.log(numeros[0]);
console.log(numeros[4]);
numeros[2] = 35;
console.log(numeros, numeros.length);

let nombres = ["Ale", "Epi", "Yun", "Emi"];

nombres.push("Tim");

console.log(nombres, nombres.length);

nombres.pop();
nombres.pop();
nombres.pop();

console.log(nombres);


let nombre = "Ale Silva";
console.log(nombre, nombre.length);