let edad = 24;
let nombre = "Ale";
let apellido = "Silva";
let esGraduado = true;
let estaCertificado = null;
let calificacion;

console.log(edad);
console.log(nombre, apellido);
console.log(esGraduado);
console.log(estaCertificado);
console.log(calificacion);

calificacion = 8.9;

console.log = calificacion;